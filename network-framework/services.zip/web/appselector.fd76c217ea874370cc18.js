;(() => {
  "use strict"
  var e = {
      460: (e, t, i) => {
        i.d(t, { Z: () => _ })
        var n = i(81),
          o = i.n(n),
          a = i(645),
          s = i.n(a),
          r = i(667),
          l = i.n(r),
          c = new URL(i(685), i.b),
          d = new URL(i(355), i.b),
          u = new URL(i(973), i.b),
          h = new URL(i(245), i.b),
          g = s()(o()),
          p = l()(c),
          m = l()(d),
          v = l()(u),
          f = l()(h)
        g.push([
          e.id,
          '@font-face{font-family:"DejaVu Sans";src:url(' +
            p +
            ') format("truetype")}html{visibility:visible !important}body{margin:0;background-color:#000000;overflow:hidden;font-family:"DejaVu Sans", sans-serif}html,body{user-select:none;-webkit-user-drag:none;-webkit-touch-callout:none;-webkit-user-select:none;-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-tap-highlight-color:transparent}img:not([src]),img[src=""]{display:none}.page-collection{position:fixed;transform:translate(-50%, -50%);top:50%;left:50%}.page{clip-path:inset(0 0 0 0);-webkit-clip-path:inset(0 0 0 0);width:100%;height:100%}.component{position:absolute;user-select:none;-webkit-user-drag:none;-webkit-user-select:none;-webkit-touch-callout:none}.component img{width:100%;height:100%;position:absolute;transform:translateZ(0px);outline:1px solid transparent}.component.button img{position:absolute}.component.gauge>canvas{position:absolute}.gauge-animation{-webkit-transition:all 0.25s ease-in-out;-moz-transition:all 0.25s ease-in-out;-o-transition:all 0.25s ease-in-out;transition:all 0.25s ease-in-out}.component.gauge>img.gauge-overlay{position:absolute}.component.indicator{pointer-events:none}.component.indicator>img{pointer-events:auto}.component.indicator.allow-click-through>img{pointer-events:none}.levelgauge-animation{-webkit-transition:clip 0.25s ease-in;-moz-transition:clip 0.25s ease-in;-o-transition:clip 0.25s ease-in;transition:clip 0.25s ease-in}.notransition *{-webkit-transition:none !important;-moz-transition:none !important;-o-transition:none !important;transition:none !important}.levelgauge-leveltracker-animation{-webkit-transition:bottom 0.25s ease-in;-moz-transition:bottom 0.25s ease-in;-o-transition:bottom 0.25s ease-in;transition:bottom 0.25s ease-in}.component.levelgauge>div.levelgauge-level{width:100%;height:100%;bottom:0px;position:absolute}.component.levelgauge>div.levelgauge-level>img.levelgauge-levelimage .component.levelgauge>div.levelgauge-level>img.levelgauge-levelimage-low-threshold,.component.levelgauge>div.levelgauge-level>img.levelgauge-levelimage-high-threshold{width:100%;height:100%;position:relative}.component.button>img.img.navigationbutton-image{z-index:0}.component.button>img.img.navigationbutton-imagepressed{z-index:10}.component.signalvalue{overflow:hidden;display:table;table-layout:fixed;white-space:nowrap}.signalvalue-inner{display:table-cell}div.signalvalue-inner>div{display:inline;font-kerning:none}.component.textbox{overflow:hidden;display:table;table-layout:fixed;white-space:nowrap}.component.textbox>div{white-space:pre;font-kerning:none;display:table-cell}.text-halign-left{text-align:left}.text-halign-center{text-align:center}.text-halign-right{text-align:right}.text-valign-top{vertical-align:top}.text-valign-middle{vertical-align:middle}.text-valign-bottom{vertical-align:bottom}.hidden{display:none !important}.test-warning-message{background-color:#0000;z-index:500;position:fixed;font-size:1vw;text-align:center;top:2rem;margin-top:2rem;padding:1rem;color:#f00;border:0.2vw solid #f00;border-radius:0.5rem;left:50%;transform:translateX(-50%)}.checksum-warning-message{background-color:#0000;z-index:500;position:fixed;font-size:1vw;text-align:center;bottom:2rem;margin-bottom:2rem;padding:1rem;color:#f00;border:0.2vw solid #f00;border-radius:0.5rem;left:50%;transform:translateX(-50%)}@media (min-aspect-ratio: 800 / 200){.test-warning-message{position:absolute;top:0;right:0;border:0;margin:auto;height:10px;font-size:0.6rem}.checksum-warning-message{position:absolute;bottom:0;right:0;border:0;margin:auto;height:10px;font-size:0.6rem}}.test-warning-message:empty{display:none}.overlay{background:black;width:100%;height:100%;z-index:500;position:fixed;top:0;left:0}.overlay .overlay-text{font-size:4vh;text-align:center;color:#888}@media (min-aspect-ratio: 800 / 200){.overlay .overlay-text{font-size:1rem}}.overlay-reload{opacity:1;animation-name:fadeInOpacity;animation-iteration-count:1;animation-timing-function:ease-in;animation-duration:1s}@keyframes fadeInOpacity{0%{opacity:0}100%{opacity:1}}.overlay .checksum-warning{font-size:2.0vw;margin-top:5vh;text-align:center;color:#f00;z-index:501}@media (min-aspect-ratio: 800 / 200){.overlay .checksum-warning{background:#000;text-align:center;position:absolute;top:0;height:100%;width:100%;padding-top:15vh;font-size:1.1vw}}.allow-click-through{pointer-events:none}.external-page{height:100%;width:100%;position:absolute;z-index:100}.external-page-navigation-back{font-size:1.0vw;background-image:linear-gradient(to bottom, #a7afb6, #55636e 5%, #55636e 50%, #282e33 100%);display:block;color:#fff;text-decoration:none;text-shadow:1px 1px #333;padding:0.5rem 2rem;border:1px solid #333435;border-radius:0.3rem;box-shadow:0px 0px 5px -2px #888888}.external-page-iframe{height:100%;width:100%}.external-page-status{height:100%;width:100%;background-color:#000;position:fixed}.external-page-status .external-page-status-text{font-size:2.5vw;text-align:center;margin-top:45vh;color:#fff}.component.indicator.allow-click-through{pointer-events:none}.animated-loader-outer{text-align:center;margin-top:45vh;margin-bottom:4vh}@media (min-aspect-ratio: 800 / 200){.animated-loader-outer{margin-top:25vh}}.animated-loader{display:inline-block;width:10vh;height:10vh}@media (min-aspect-ratio: 800 / 200){.animated-loader{width:1rem;height:1rem}}.animated-loader:after{content:" ";display:block;width:7vh;height:7vh;margin:0;border-radius:50%;border:0.2rem solid #888;border-color:#888 transparent #888 transparent;animation:animated-loader 1.0s linear infinite}@media (min-aspect-ratio: 800 / 200){.animated-loader:after{width:0.8rem;height:0.8rem;border:0.15rem solid #888;border-color:#888 transparent #888 transparent}}@keyframes animated-loader{0%{transform:rotate(0deg)}25%{transform:rotate(90deg)}50%{transform:rotate(270deg)}100%{transform:rotate(360deg)}}::-webkit-scrollbar{-webkit-appearance:none;width:8px}::-webkit-scrollbar-track{background-color:rgba(57,57,57,0.6);border-radius:8px}::-webkit-scrollbar-thumb{border-radius:8px;background-color:rgba(156,156,156,0.6)}.app-selector-link-timer-dialog{z-index:1010;position:fixed;background-color:rgba(255,255,255,0);top:0;right:0;bottom:0;left:0;pointer-events:none;transition:all 2.0s}.app-selector-link-timer-dialog>div{width:38vh;position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);padding:2vh;background:white;pointer-events:auto;background-color:#161616;border:0.01vh solid #444}.app-selector-link-timer-dialog-button{display:inline-block;background:#737373;color:#e2e2e2;padding:0vh;margin:0 0 1.0vh 0;box-sizing:border-box !important;text-decoration:none;cursor:pointer;width:100%;font-size:4vh;height:10vh;vertical-align:middle;border-top:0.15vh solid #ababab;border-bottom:0.1vh solid #000000;pointer-events:auto !important}.app-selector-link-timer{display:inline-block;width:28vh;height:28vh;z-index:1000;position:fixed;transform:translate(-50%, -50%)}.app-selector-link-timer-progress-bar{stroke-dasharray:296 296;stroke-dashoffset:296;animation:grow 10s linear infinite, fade-in 10s}@keyframes grow{100%{stroke-dashoffset:0}}@keyframes fade-in{0%{opacity:0}20%{opacity:0}50%{opacity:0.5}100%{opacity:0.5}}.log-view{position:fixed;z-index:9989;color:white;background-color:black;top:0;left:0;width:100%;height:100%;display:block;overflow:hidden;font-size:x-large;opacity:0.8}.log-view-minimized{height:45px !important}.log-view-content{padding:15px;overflow-y:scroll;height:90vh;width:100vw;word-wrap:break-word}.maximize-log-button{position:absolute;right:0;top:0;padding:8px;z-index:9989;display:none}.log-button{float:right;padding:8px;margin-right:15px;margin-top:0px}body{overflow-x:hidden;overflow-y:auto;height:100vh}.hidden{display:none}.application-selector{padding-top:80px;padding-bottom:80px;padding-left:80px;padding-right:80px}.application{height:240px;width:300px;display:grid;grid-template-rows:10px 190px 10px 30px}.application-not-default{display:none}.application-selector-show-all .application-not-default{opacity:.5;display:grid}.application-selector-edit-mode .application-not-default{display:grid;opacity:.5}.application-selector-edit-mode .application-not-default:after{background-image:url(' +
            m +
            ");background-repeat:no-repeat;content:'';width:60px;height:60px;margin-left:20px;margin-top:20px;opacity:1.0}.application-selector-edit-mode .application:not(.application-not-default):after{background-image:url(" +
            v +
            ');background-repeat:no-repeat;content:\'\';width:60px;height:60px;margin-left:20px;margin-top:20px}.application{cursor:pointer;text-align:center}.application-list{display:flex;flex-direction:row;flex-wrap:wrap;overflow-y:hidden;overflow-x:hidden;padding:17px}.application-selector-edit-mode .application-list{border-color:#90ffa9;border-width:1px;border-style:solid;padding:16px}.application-selector-top{min-height:120px;padding-bottom:16px;display:flex;justify-content:flex-start}.application-selector:not(.application-selector-edit-mode) .application-selector-top-edit-mode-text{display:none}.application-selector-edit-mode .application-selector-top-edit-mode-text{font-size:1rem;color:#90FFA9}.application-selector-top-title{font-size:3rem;color:#ffffff;flex-grow:1}.application-selector-edit-mode .application-list-save-button{display:inline-block}.application-list-save-button{display:none;color:#e2e2e2;background:#737373;padding:1rem;margin:0 0 0.5rem 0;box-sizing:border-box;text-decoration:none;cursor:pointer;border-top:1.5px solid #ababab;border-bottom:1px solid #000000;pointer-events:auto;font-size:28px;vertical-align:middle;height:60px;width:320px;text-align:center;padding-top:8px;justify-self:flex-end}.application-list-save-button-text{font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Ubuntu, "Helvetica Neue", Helvetica, sans-serif;line-height:1.5}.application-selector-show-all:not(.application-selector-edit-mode) .application-selector-edit-button{height:30px;width:60px;padding-top:8px;background-image:url(' +
            f +
            ");background-size:contain;background-repeat:no-repeat;opacity:0.3}.application-name{font-size:24px;color:#FFFFFF;grid-row:4;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.application-icon{object-fit:contain;max-width:95%;max-height:100%;width:auto;height:auto;grid-row:2;justify-self:center;align-self:center;background-color:#333;padding:16px}.application-icon>img{width:250px;height:166px}.test-warning-message,.checksum-warning-message{font-size:1rem}@media (max-width: 500px){.application-selector{padding-left:20px;padding-right:20px}.application-list{justify-content:center}.application-selector-top-title{font-size:2rem}}@media (min-width: 1921px){body{zoom:200%}}\n",
          "",
        ])
        const _ = g
      },
      645: (e) => {
        e.exports = function (e) {
          var t = []
          return (
            (t.toString = function () {
              return this.map(function (t) {
                var i = "",
                  n = void 0 !== t[5]
                return (
                  t[4] && (i += "@supports (".concat(t[4], ") {")),
                  t[2] && (i += "@media ".concat(t[2], " {")),
                  n &&
                    (i += "@layer".concat(
                      t[5].length > 0 ? " ".concat(t[5]) : "",
                      " {"
                    )),
                  (i += e(t)),
                  n && (i += "}"),
                  t[2] && (i += "}"),
                  t[4] && (i += "}"),
                  i
                )
              }).join("")
            }),
            (t.i = function (e, i, n, o, a) {
              "string" == typeof e && (e = [[null, e, void 0]])
              var s = {}
              if (n)
                for (var r = 0; r < this.length; r++) {
                  var l = this[r][0]
                  null != l && (s[l] = !0)
                }
              for (var c = 0; c < e.length; c++) {
                var d = [].concat(e[c])
                ;(n && s[d[0]]) ||
                  (void 0 !== a &&
                    (void 0 === d[5] ||
                      (d[1] = "@layer"
                        .concat(d[5].length > 0 ? " ".concat(d[5]) : "", " {")
                        .concat(d[1], "}")),
                    (d[5] = a)),
                  i &&
                    (d[2]
                      ? ((d[1] = "@media "
                          .concat(d[2], " {")
                          .concat(d[1], "}")),
                        (d[2] = i))
                      : (d[2] = i)),
                  o &&
                    (d[4]
                      ? ((d[1] = "@supports ("
                          .concat(d[4], ") {")
                          .concat(d[1], "}")),
                        (d[4] = o))
                      : (d[4] = "".concat(o))),
                  t.push(d))
              }
            }),
            t
          )
        }
      },
      667: (e) => {
        e.exports = function (e, t) {
          return (
            t || (t = {}),
            e
              ? ((e = String(e.__esModule ? e.default : e)),
                /^['"].*['"]$/.test(e) && (e = e.slice(1, -1)),
                t.hash && (e += t.hash),
                /["'() \t\n]|(%20)/.test(e) || t.needQuotes
                  ? '"'.concat(
                      e.replace(/"/g, '\\"').replace(/\n/g, "\\n"),
                      '"'
                    )
                  : e)
              : e
          )
        }
      },
      81: (e) => {
        e.exports = function (e) {
          return e[1]
        }
      },
      379: (e) => {
        var t = []
        function i(e) {
          for (var i = -1, n = 0; n < t.length; n++)
            if (t[n].identifier === e) {
              i = n
              break
            }
          return i
        }
        function n(e, n) {
          for (var a = {}, s = [], r = 0; r < e.length; r++) {
            var l = e[r],
              c = n.base ? l[0] + n.base : l[0],
              d = a[c] || 0,
              u = "".concat(c, " ").concat(d)
            a[c] = d + 1
            var h = i(u),
              g = {
                css: l[1],
                media: l[2],
                sourceMap: l[3],
                supports: l[4],
                layer: l[5],
              }
            if (-1 !== h) t[h].references++, t[h].updater(g)
            else {
              var p = o(g, n)
              ;(n.byIndex = r),
                t.splice(r, 0, { identifier: u, updater: p, references: 1 })
            }
            s.push(u)
          }
          return s
        }
        function o(e, t) {
          var i = t.domAPI(t)
          i.update(e)
          return function (t) {
            if (t) {
              if (
                t.css === e.css &&
                t.media === e.media &&
                t.sourceMap === e.sourceMap &&
                t.supports === e.supports &&
                t.layer === e.layer
              )
                return
              i.update((e = t))
            } else i.remove()
          }
        }
        e.exports = function (e, o) {
          var a = n((e = e || []), (o = o || {}))
          return function (e) {
            e = e || []
            for (var s = 0; s < a.length; s++) {
              var r = i(a[s])
              t[r].references--
            }
            for (var l = n(e, o), c = 0; c < a.length; c++) {
              var d = i(a[c])
              0 === t[d].references && (t[d].updater(), t.splice(d, 1))
            }
            a = l
          }
        }
      },
      569: (e) => {
        var t = {}
        e.exports = function (e, i) {
          var n = (function (e) {
            if (void 0 === t[e]) {
              var i = document.querySelector(e)
              if (
                window.HTMLIFrameElement &&
                i instanceof window.HTMLIFrameElement
              )
                try {
                  i = i.contentDocument.head
                } catch (n) {
                  i = null
                }
              t[e] = i
            }
            return t[e]
          })(e)
          if (!n)
            throw new Error(
              "Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid."
            )
          n.appendChild(i)
        }
      },
      216: (e) => {
        e.exports = function (e) {
          var t = document.createElement("style")
          return e.setAttributes(t, e.attributes), e.insert(t, e.options), t
        }
      },
      565: (e, t, i) => {
        e.exports = function (e) {
          var t = i.nc
          t && e.setAttribute("nonce", t)
        }
      },
      795: (e) => {
        e.exports = function (e) {
          var t = e.insertStyleElement(e)
          return {
            update: function (i) {
              !(function (e, t, i) {
                var n = ""
                i.supports && (n += "@supports (".concat(i.supports, ") {")),
                  i.media && (n += "@media ".concat(i.media, " {"))
                var o = void 0 !== i.layer
                o &&
                  (n += "@layer".concat(
                    i.layer.length > 0 ? " ".concat(i.layer) : "",
                    " {"
                  )),
                  (n += i.css),
                  o && (n += "}"),
                  i.media && (n += "}"),
                  i.supports && (n += "}")
                var a = i.sourceMap
                a &&
                  "undefined" != typeof btoa &&
                  (n +=
                    "\n/*# sourceMappingURL=data:application/json;base64,".concat(
                      btoa(unescape(encodeURIComponent(JSON.stringify(a)))),
                      " */"
                    )),
                  t.styleTagTransform(n, e, t.options)
              })(t, e, i)
            },
            remove: function () {
              !(function (e) {
                if (null === e.parentNode) return !1
                e.parentNode.removeChild(e)
              })(t)
            },
          }
        }
      },
      589: (e) => {
        e.exports = function (e, t) {
          if (t.styleSheet) t.styleSheet.cssText = e
          else {
            for (; t.firstChild; ) t.removeChild(t.firstChild)
            t.appendChild(document.createTextNode(e))
          }
        }
      },
      685: (e, t, i) => {
        e.exports = i.p + "b0a0bdae520210e3569b.TTF"
      },
      973: (e, t, i) => {
        e.exports = i.p + "images/checkbox-checked.svg"
      },
      355: (e, t, i) => {
        e.exports = i.p + "images/checkbox-unchecked.svg"
      },
      245: (e, t, i) => {
        e.exports = i.p + "images/cog.svg"
      },
    },
    t = {}
  function i(n) {
    var o = t[n]
    if (void 0 !== o) return o.exports
    var a = (t[n] = { id: n, exports: {} })
    return e[n](a, a.exports, i), a.exports
  }
  ;(i.m = e),
    (i.n = (e) => {
      var t = e && e.__esModule ? () => e.default : () => e
      return i.d(t, { a: t }), t
    }),
    (i.d = (e, t) => {
      for (var n in t)
        i.o(t, n) &&
          !i.o(e, n) &&
          Object.defineProperty(e, n, { enumerable: !0, get: t[n] })
    }),
    (i.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
    (i.p = ""),
    (i.b = document.baseURI || self.location.href),
    (i.nc = void 0),
    (() => {
      var e = i(379),
        t = i.n(e),
        n = i(795),
        o = i.n(n),
        a = i(569),
        s = i.n(a),
        r = i(565),
        l = i.n(r),
        c = i(216),
        d = i.n(c),
        u = i(589),
        h = i.n(u),
        g = i(460),
        p = {}
      ;(p.styleTagTransform = h()),
        (p.setAttributes = l()),
        (p.insert = s().bind(null, "head")),
        (p.domAPI = o()),
        (p.insertStyleElement = d())
      t()(g.Z, p)
      g.Z && g.Z.locals && g.Z.locals
      function m(e, t, i, n) {
        return new (i || (i = Promise))(function (o, a) {
          function s(e) {
            try {
              l(n.next(e))
            } catch (t) {
              a(t)
            }
          }
          function r(e) {
            try {
              l(n.throw(e))
            } catch (t) {
              a(t)
            }
          }
          function l(e) {
            var t
            e.done
              ? o(e.value)
              : ((t = e.value),
                t instanceof i
                  ? t
                  : new i(function (e) {
                      e(t)
                    })).then(s, r)
          }
          l((n = n.apply(e, t || [])).next())
        })
      }
      Object.create
      var v, f, _, b, w, y, S, k, E, x, C, D, M, T, I
      Object.create
      !(function (e) {
        ;(e[(e.off = 0)] = "off"),
          (e[(e.error = 1)] = "error"),
          (e[(e.warning = 2)] = "warning"),
          (e[(e.info = 3)] = "info"),
          (e[(e.verbose = 4)] = "verbose"),
          (e[(e.debug = 5)] = "debug")
      })(v || (v = {}))
      class L {
        static logError(e, ...t) {
          this.logLevel >= v.error &&
            (console.error(e, ...t), L._checkAutoRefresh())
        }
        static _checkAutoRefresh() {
          L.autoRefresh && L._populateLog()
        }
        static logWarning(e, ...t) {
          L.logLevel >= v.warning &&
            (console.log(e, ...t), L._checkAutoRefresh())
        }
        static logInfo(e, ...t) {
          L.logLevel >= v.info && (console.log(e, ...t), L._checkAutoRefresh())
        }
        static logVerbose(e, ...t) {
          L.logLevel >= v.verbose &&
            (console.log(e, ...t), L._checkAutoRefresh())
        }
        static logDebug(e, ...t) {
          L.logLevel >= v.debug && (console.log(e, ...t), L._checkAutoRefresh())
        }
        static initialize() {
          !0 !== L._isInitialized &&
            ((L._isInitialized = !0),
            document.addEventListener(
              "mousedown",
              (e) => L._handleStartLogView(),
              !0
            ),
            document.addEventListener("keydown", (e) => {
              L._debugModeActive ||
                (e.ctrlKey && e.altKey && "l" === e.key && L.showLogView())
            }))
        }
        static showLogView() {
          L._debugModeActive = !0
          let e = document.querySelector(".log-view-wrapper")
          null == e && (e = L._setupLogView()),
            L._populateLog(),
            (e.style.display = "block")
        }
        static _closeLog() {
          ;(L._state = 0),
            (L._shortPressCount = 0),
            (L._debugModeActive = !1),
            (L.logLevel = v.error)
          document.querySelector(".log-view-wrapper").style.display = "none"
          document.querySelector(".log-view-content").innerHTML = ""
        }
        static _clearLog() {
          globalLogMessages.splice(0), this._populateLog()
        }
        static _maximizeLog() {
          document.querySelector(".log-view").style.display = "block"
          document.querySelector(".maximize-log-button").style.display = "none"
        }
        static _mimimizeLog() {
          document.querySelector(".log-view").style.display = "none"
          document.querySelector(".maximize-log-button").style.display = "block"
        }
        static _setAutoRefreshLog() {
          const e = document.querySelector(".auto-refresh-log-button")
          !0 === L.autoRefresh
            ? ((L.autoRefresh = !1), (e.innerText = "Turn Auto Refresh On"))
            : ((L.autoRefresh = !0), (e.innerText = "Turn Auto Refresh Off"))
        }
        static _handleStartLogView() {
          if (L._debugModeActive) L._lastClick = new Date()
          else {
            if (
              (L._durationGreaterThan(3 * L._activateDuration, L._lastClick) &&
                ((L._state = 0), (L._shortPressCount = 0)),
              L._state % 2 != 0 &&
                (L._durationGreaterThan(L._activateDuration, L._lastClick)
                  ? L._state++
                  : (L._state = 0),
                (L._shortPressCount = 0)),
              L._state % 2 == 0)
            ) {
              if (
                (0 === L._shortPressCount && (L._clickStart = new Date()),
                L._shortPressCount < L._requiredShortPressCount &&
                  L._durationGreaterThan(L._activateDuration, L._clickStart))
              )
                return (L._state = 0), void (L._shortPressCount = 0)
              L._shortPressCount++,
                L._shortPressCount >= L._requiredShortPressCount &&
                  (L._state++, (L._clickStart = new Date()))
            }
            ;(L._lastClick = new Date()),
              L._state > 6 &&
                ((L._state = 0), (L._shortPressCount = 0), L.showLogView())
          }
        }
        static _durationGreaterThan(e, t) {
          return new Date().getTime() - t.getTime() > e
        }
        static _setupLogView() {
          const e = document.querySelector("body"),
            t = document.createElement("div")
          t.classList.add("log-view-wrapper"),
            (t.innerHTML = `\n        <button class="maximize-log-button">Maximize</button>\n        <div class="log-view">\n            <div class="log-view-toobar">\n            <button class="close-log-button log-button">Exit</button>\n            <button class="clear-log-button log-button">Clear</button>\n            <button class="minimize-log-button log-button">Minimize</button>\n            <button class="refresh-log-button log-button">Refresh</button>\n            <button class="auto-refresh-log-button log-button">${
              !1 === L.autoRefresh
                ? "Turn Auto Refresh On"
                : "Turn Auto Refresh Off"
            }</button>\n            <select class="log-level-selector log-button">\n                <option value="5" ${
              L.logLevel === v.debug ? "selected" : ""
            }>Debug</option>\n                <option value="4" ${
              L.logLevel === v.verbose ? "selected" : ""
            }>Verbose</option>\n                <option value="3" ${
              L.logLevel === v.info ? "selected" : ""
            }>Info</option>\n                <option value="2" ${
              L.logLevel === v.warning ? "selected" : ""
            }>Warning</option>\n                <option value="1" ${
              L.logLevel === v.error ? "selected" : ""
            } >Error</option>\n                <option value="0" ${
              L.logLevel === v.off ? "selected" : ""
            }>Off</option>\n            </select>\n            </div>\n            <div class="log-view-content">\n            </div>\n        </div>`),
            e.appendChild(t)
          document.querySelector(".log-level-selector").onchange = (e) => {
            const t = e.target
            L.logLevel = parseInt(t.value, 10)
          }
          document.querySelector(".close-log-button").onclick = () =>
            L._closeLog()
          document.querySelector(".clear-log-button").onclick = () =>
            L._clearLog()
          document.querySelector(".minimize-log-button").onclick = () =>
            L._mimimizeLog()
          document.querySelector(".maximize-log-button").onclick = () =>
            L._maximizeLog()
          document.querySelector(".refresh-log-button").onclick = () =>
            L._populateLog()
          return (
            (document.querySelector(".auto-refresh-log-button").onclick = () =>
              L._setAutoRefreshLog()),
            t
          )
        }
        static _populateLog() {
          const e = document.querySelector(".log-view-content")
          e.innerHTML = ""
          for (let t = globalLogMessages.length - 1; t >= 0; t--) {
            const i = globalLogMessages[t],
              n = document.createElement("div"),
              o = document.createTextNode(i)
            n.appendChild(o), e.appendChild(n)
          }
        }
      }
      ;(L._clickStart = new Date()),
        (L._lastClick = new Date()),
        (L._isInitialized = !1),
        (L._debugModeActive = !1),
        (L._activateDuration = 2e3),
        (L._requiredShortPressCount = 3),
        (L._shortPressCount = 0),
        (L._state = 0),
        (L.logLevel = v.error),
        (L.autoRefresh = !1),
        (function (e) {
          ;(e[(e.notSet = 0)] = "notSet"),
            (e[(e.closed = 1)] = "closed"),
            (e[(e.connecting = 2)] = "connecting"),
            (e[(e.open = 3)] = "open"),
            (e[(e.socketError = 4)] = "socketError")
        })(f || (f = {}))
      class R {
        constructor() {
          ;(this.currentState = f.notSet),
            (this.autoReconnectOnError = !1),
            (this._webSocket = null),
            (this._onMessageDelegates = []),
            (this._onSocketStateChangesDelegates = [])
        }
        connect() {
          this._createNewWebSocket()
        }
        addOnDataReceivedDelegate(e) {
          this._onMessageDelegates.push(e)
        }
        removeOnDataReceivedDelegate(e) {
          for (let t = 0; t < this._onMessageDelegates.length; t++)
            if (this._onMessageDelegates[t] === e)
              return void this._onMessageDelegates.splice(t, 1)
        }
        addOnSocketStateChangedDelegate(e) {
          this._onSocketStateChangesDelegates.push(e), e(this.currentState)
        }
        removeOnSocketStateChangedDelegate(e) {
          for (let t = 0; t < this._onSocketStateChangesDelegates.length; t++)
            if (this._onSocketStateChangesDelegates[t] === e)
              return void this._onSocketStateChangesDelegates.splice(t, 1)
        }
        sendJson(e) {
          this.send(JSON.stringify(e))
        }
        send(e) {
          null == this._webSocket ||
          this._webSocket.readyState !== this._webSocket.OPEN
            ? L.logWarning("Websocket is not open, failed to send command!")
            : (L.logDebug("Sending ws data: ", e), this._webSocket.send(e))
        }
        _createNewWebSocket() {
          if (null != this._webSocket)
            try {
              ;(this._webSocket.readyState !== this._webSocket.OPEN &&
                this._webSocket.readyState !== this._webSocket.CONNECTING) ||
                this._webSocket.close(),
                this._onSocketClosed()
            } catch (e) {}
          ;(this._webSocket = new WebSocket(
            "ws://" + window.location.host + "/ws"
          )),
            (this._webSocket.onopen = (e) => this._onOpen(e)),
            (this._webSocket.onmessage = (e) => this._onMessageReceived(e)),
            (this._webSocket.onerror = (e) => this._onSocketError(e)),
            (this._webSocket.onclose = (e) => this._onSocketClosed()),
            this._onSocketStateChanged(f.connecting)
        }
        _onMessageReceived(e) {
          const t = JSON.parse(e.data)
          if (null != t) {
            L.logDebug(
              `Received ws data. cmd: ${t.messagecmd}, type: ${t.messagetype}, size: ${t.size}`
            )
            for (const e of this._onMessageDelegates) e(t)
          } else L.logDebug("Received ws data with value null")
        }
        _onSocketError(e) {
          L.logError(
            "Websocket return onError, socket state: " +
              this._webSocket.readyState
          ),
            this._onSocketStateChanged(f.socketError),
            this.autoReconnectOnError &&
              (L.logWarning("Websocket error: Recreate websocket"),
              this._createNewWebSocket())
        }
        _onSocketClosed() {
          this._onSocketStateChanged(f.closed)
        }
        _onOpen(e) {
          this._onSocketStateChanged(f.open)
        }
        _onSocketStateChanged(e) {
          ;(this.currentState = e), this._notifySocketStateSubscribers(e)
        }
        _notifySocketStateSubscribers(e) {
          for (const t of this._onSocketStateChangesDelegates) t(e)
        }
      }
      class W {
        static receivedWduHeartbetAckCommand() {
          return {
            messagetype: b.acknowledgement,
            messagecmd: E.acknowledgementAck,
            size: 1,
            data: [0],
          }
        }
        static requestWduInfoCommand() {
          return { messagetype: 49, messagecmd: 1, size: 3, data: [0, 0, 0] }
        }
        static requestApplicationSelectorInfoAvailableApplications(e) {
          return {
            messagetype: 49,
            messagecmd: 5,
            size: 0,
            data: [],
            extradata: { type: 1, clientId: e },
          }
        }
        static applicationSelectorSetDefaultApplication(e, t) {
          return {
            messagetype: b.systemWrite,
            messagecmd: 7,
            size: 0,
            data: [],
            extradata: { type: 2, identifiers: e, clientId: t },
          }
        }
        static applicationSelectorClearDefaultApplication() {
          return {
            messagetype: b.systemWrite,
            messagecmd: 7,
            size: 0,
            data: [],
            extradata: { type: 1 },
          }
        }
        static momentaryCommand(e, t) {
          return {
            messagetype: 17,
            messagecmd: 1,
            size: 3,
            data: [e, e >> 8, t ? 1 : 0],
          }
        }
        static toggleCommand(e, t, i, n) {
          let o = 0
          return (
            t && (o |= 1),
            i && (o |= 2),
            n && (o |= 4),
            { messagetype: 17, messagecmd: 0, size: 3, data: [e, e >> 8, o] }
          )
        }
        static dimmerCommand(e, t, i) {
          return {
            messagetype: 17,
            messagecmd: 3,
            size: 5,
            data: [e, e >> 8, i, 255 & t, (t >> 8) & 255],
          }
        }
      }
      class U {
        equals(e) {
          return (
            this.signalId === e.signalId &&
            this.unavailable === e.unavailable &&
            this.valueTypeIdentifier === e.valueTypeIdentifier &&
            this.value === e.value
          )
        }
      }
      !(function (e) {
        ;(e[(e.pulse = 0)] = "pulse"),
          (e[(e.momentary = 1)] = "momentary"),
          (e[(e.dimmer = 3)] = "dimmer"),
          (e[(e.statusUpdate = 5)] = "statusUpdate")
      })(_ || (_ = {}))
      class P extends U {
        equals(e) {
          return (
            this.signalId === e.signalId &&
            this.unavailable === e.unavailable &&
            this.valueTypeIdentifier === e.valueTypeIdentifier &&
            this.value === e.value &&
            this.type === e.type &&
            this.onOffStatus === e.onOffStatus &&
            this.err1FT === e.err1FT &&
            this.err2UC === e.err2UC &&
            this.dimmerValue === e.dimmerValue
          )
        }
      }
      !(function (e) {
        ;(e[(e.mfdStatus = 16)] = "mfdStatus"),
          (e[(e.mfdControl = 17)] = "mfdControl"),
          (e[(e.channelInfo = 32)] = "channelInfo"),
          (e[(e.channelCmd = 33)] = "channelCmd"),
          (e[(e.systemCmd = 48)] = "systemCmd"),
          (e[(e.systemReq = 49)] = "systemReq"),
          (e[(e.systemWrite = 50)] = "systemWrite"),
          (e[(e.syncCmd = 64)] = "syncCmd"),
          (e[(e.alertManagement = 81)] = "alertManagement"),
          (e[(e.nmeaMsg = 82)] = "nmeaMsg"),
          (e[(e.subscriptionRequest = 96)] = "subscriptionRequest"),
          (e[(e.clientControlCommand = 112)] = "clientControlCommand"),
          (e[(e.acknowledgement = 128)] = "acknowledgement")
      })(b || (b = {})),
        (function (e) {
          ;(e[(e.serviceProviderHeartbeat = 0)] = "serviceProviderHeartbeat"),
            (e[(e.wduInfo = 1)] = "wduInfo"),
            (e[(e.wduSettingsUpdated = 4)] = "wduSettingsUpdated"),
            (e[(e.wduHeartbeat = 5)] = "wduHeartbeat"),
            (e[(e.applicationSelection = 10)] = "applicationSelection")
        })(w || (w = {})),
        (function (e) {
          ;(e[(e.toggle = 0)] = "toggle"),
            (e[(e.momentary = 1)] = "momentary"),
            (e[(e.dimmerUpdate = 3)] = "dimmerUpdate"),
            (e[(e.statusUpdate = 5)] = "statusUpdate")
        })(y || (y = {})),
        (function (e) {
          e[(e.statusUpdate = 1)] = "statusUpdate"
        })(S || (S = {})),
        (function (e) {
          e[(e.forceReload = 1)] = "forceReload"
        })(k || (k = {})),
        (function (e) {
          e[(e.acknowledgementAck = 0)] = "acknowledgementAck"
        })(E || (E = {})),
        (function (e) {
          ;(e[(e.uint32 = 0)] = "uint32"),
            (e[(e.int32 = 1)] = "int32"),
            (e[(e.uint16 = 2)] = "uint16"),
            (e[(e.int16 = 3)] = "int16"),
            (e[(e.uint8 = 4)] = "uint8"),
            (e[(e.int8 = 5)] = "int8"),
            (e[(e.uint64 = 6)] = "uint64"),
            (e[(e.int64 = 7)] = "int64"),
            (e[(e.bit = 8)] = "bit")
        })(x || (x = {}))
      class A {
        static start() {
          this._isStarted ||
            ((this._isStarted = !0),
            window.setInterval(() => A._incrementTicks(), 1e3))
        }
        static timestamp() {
          return A._ticks
        }
        static elapsedSeconds(e) {
          return A._ticks - e
        }
        static _incrementTicks() {
          A._ticks++
        }
      }
      ;(A._ticks = 0),
        (A._isStarted = !1),
        (function (e) {
          ;(e[(e.equal = 0)] = "equal"),
            (e[(e.notEqual = 1)] = "notEqual"),
            (e[(e.greaterThan = 2)] = "greaterThan"),
            (e[(e.lessThan = 3)] = "lessThan"),
            (e[(e.greaterThanOrEqual = 4)] = "greaterThanOrEqual"),
            (e[(e.lessThanOrEqual = 5)] = "lessThanOrEqual"),
            (e[(e.between = 6)] = "between"),
            (e[(e.notBetween = 7)] = "notBetween"),
            (e[(e.disabled = 8)] = "disabled")
        })(C || (C = {})),
        (function (e) {
          ;(e[(e.forcePageReload = 0)] = "forcePageReload"),
            (e[(e.settingsUpdated = 1)] = "settingsUpdated"),
            (e[(e.wduInfoReceived = 3)] = "wduInfoReceived"),
            (e[(e.checksumReceived = 4)] = "checksumReceived"),
            (e[(e.applicationSelectionListReceived = 5)] =
              "applicationSelectionListReceived")
        })(D || (D = {})),
        (function (e) {
          ;(e[(e.notSet = 0)] = "notSet"),
            (e[(e.ok = 1)] = "ok"),
            (e[(e.noConnectionToDigitalSwitching = 2)] =
              "noConnectionToDigitalSwitching"),
            (e[(e.noConnectionToWdu = 3)] = "noConnectionToWdu")
        })(M || (M = {}))
      class O {
        constructor(e, t) {
          ;(this.configurationChecksumFromWDU = null),
            (this.watchdogState = M.notSet),
            (this._webSocketManager = null),
            (this._nmeaValueReceivedDelegatesMap = new Map()),
            (this._mdfValueReceivedDelegatesMap = new Map()),
            (this._onWatchdogStateChangesDelegates = []),
            (this._commandReceivedDelegates = []),
            (this._digitalSwitchingHeartbeatTimestamp = 0),
            (this._lastReceivedMessageTimestamp = 0),
            (this._oldHeartbeatDurationDivider = 0),
            (this._watchdogDuration = 2e3),
            (this._protocolVersion = [1, 0, 0]),
            (this._wduInfoReceived = !1),
            (this._receivedNmeaDataMap = new Map()),
            (this._receivedMfdDataMap = new Map()),
            (this._webSocketManager = e),
            (this._contentDecoder = t),
            this._webSocketManager.addOnDataReceivedDelegate((e) =>
              this._onMessageReceived(e)
            ),
            (this._lastReceivedMessageTimestamp = A.timestamp()),
            setTimeout(() => this._watchdogLoop(), 2 * this._watchdogDuration)
        }
        getProtocolVersion() {
          return this._protocolVersion
        }
        addOnNmeaValueReceivedDelegate(e, t) {
          let i = []
          this._nmeaValueReceivedDelegatesMap.has(e)
            ? (i = this._nmeaValueReceivedDelegatesMap.get(e))
            : this._nmeaValueReceivedDelegatesMap.set(e, i),
            i.push(t)
        }
        addOnMfdValueReceivedDelegate(e, t) {
          let i = []
          this._mdfValueReceivedDelegatesMap.has(e)
            ? (i = this._mdfValueReceivedDelegatesMap.get(e))
            : this._mdfValueReceivedDelegatesMap.set(e, i),
            i.push(t)
        }
        addOnCommandReceivedDelegate(e) {
          this._commandReceivedDelegates.push(e)
        }
        addWatchdogStateChangedDelegate(e) {
          this._onWatchdogStateChangesDelegates.push(e), e(this.watchdogState)
        }
        removeOnWathdogStateChangedDelegate(e) {
          for (let t = 0; t < this._onWatchdogStateChangesDelegates.length; t++)
            if (this._onWatchdogStateChangesDelegates[t] === e)
              return void this._onWatchdogStateChangesDelegates.splice(t, 1)
        }
        send(e) {
          this._webSocketManager.sendJson(e)
        }
        _notifyMdfValueSubscribers(e) {
          if (!this._isNewMfdData(e)) return
          const t = this._mdfValueReceivedDelegatesMap.get(e.signalId)
          if (null != t) for (const i of t) i(e)
        }
        _notifyNmeaValueSubscribers(e) {
          if (!this._isNewNmeaData(e)) return
          const t = this._nmeaValueReceivedDelegatesMap.get(e.signalId)
          if (null != t) for (const i of t) i(e)
        }
        _isNewMfdData(e) {
          if (this._receivedMfdDataMap.has(e.signalId)) {
            if (this._receivedMfdDataMap.get(e.signalId).equals(e)) return !1
          }
          return this._receivedMfdDataMap.set(e.signalId, e), !0
        }
        _isNewNmeaData(e) {
          if (this._receivedNmeaDataMap.has(e.signalId)) {
            if (this._receivedNmeaDataMap.get(e.signalId).equals(e)) return !1
          }
          return this._receivedNmeaDataMap.set(e.signalId, e), !0
        }
        _onMessageReceived(e) {
          switch (
            ((this._lastReceivedMessageTimestamp = A.timestamp()),
            e.messagetype)
          ) {
            case b.mfdStatus:
              this._propagateMfdMessage(
                this._contentDecoder.decodeMFDChannelItem(e)
              )
              break
            case b.nmeaMsg:
              this._propagateNmeaMessage(
                this._contentDecoder.decodeN2KDataItem(e)
              )
              break
            case b.systemCmd:
              if (e.messagecmd === w.wduInfo) {
                ;(this._wduSendsHeartbeat =
                  e.data[0] > 1 || (1 === e.data[0] && e.data[1] >= 2)),
                  (this._protocolVersion[0] = e.data[0]),
                  (this._protocolVersion[1] = e.data[1]),
                  (this._wduInfoReceived = !0),
                  L.logVerbose(
                    `WDU Info Received. Enable WDU heartbeat set to ${this._wduSendsHeartbeat}`
                  )
                for (const e of this._commandReceivedDelegates)
                  e(D.wduInfoReceived)
              } else if (e.messagecmd === w.serviceProviderHeartbeat) {
                ;(this.configurationChecksumFromWDU =
                  (e.data[1] |
                    (e.data[2] << 8) |
                    (e.data[3] << 16) |
                    (e.data[4] << 24)) >>>
                  0),
                  (this._digitalSwitchingHeartbeatTimestamp = A.timestamp()),
                  0 !== this.configurationChecksumFromWDU &&
                    this._checkWatchdog()
                for (const e of this._commandReceivedDelegates)
                  e(D.checksumReceived)
                L.logVerbose("Service provider heartbeat received")
              } else if (e.messagecmd === w.wduHeartbeat)
                L.logDebug("Received wdu heart beat."),
                  this.send(W.receivedWduHeartbetAckCommand())
              else if (e.messagecmd === w.wduSettingsUpdated)
                for (const e of this._commandReceivedDelegates)
                  e(D.settingsUpdated)
              else if (e.messagecmd === w.applicationSelection)
                for (const t of this._commandReceivedDelegates)
                  t(D.applicationSelectionListReceived, e.extradata)
              break
            case b.clientControlCommand:
              if (e.messagecmd === k.forceReload) {
                for (const e of this._commandReceivedDelegates)
                  e(D.forcePageReload)
                setTimeout(() => {
                  window.location.reload()
                }, 5e3)
              }
          }
        }
        _propagateMfdMessage(e) {
          if (null == e) return
          this._notifyMdfValueSubscribers(e)
          const t = this._contentDecoder.getVirtualSignals(e.signalId)
          for (const i of t) {
            const t = new P()
            ;(t.unavailable =
              !!e.unavailable ||
              this._evaluate(e.value, i.unAvailableExpression)),
              (t.onOffStatus = this._evaluate(e.value, i.statusExpression)),
              (t.signalId = i.signalId),
              (t.type = _.momentary),
              this._notifyMdfValueSubscribers(t)
          }
        }
        _propagateNmeaMessage(e) {
          if (null == e) return
          this._notifyNmeaValueSubscribers(e)
          const t = this._contentDecoder.getVirtualSignals(e.signalId)
          for (const i of t) {
            const t = new P()
            ;(t.unavailable =
              !!e.unavailable ||
              this._evaluate(e.value, i.unAvailableExpression)),
              (t.onOffStatus = this._evaluate(e.value, i.statusExpression)),
              (t.type = _.momentary),
              (t.signalId = i.signalId),
              this._notifyMdfValueSubscribers(t)
          }
        }
        _evaluate(e, t) {
          switch (t.expressionType) {
            case C.disabled:
              return !1
            case C.equal:
              return e === t.valueA
            case C.notEqual:
              return e !== t.valueA
            case C.greaterThan:
              return e > t.valueA
            case C.lessThan:
              return e < t.valueA
            case C.greaterThanOrEqual:
              return e >= t.valueA
            case C.lessThanOrEqual:
              return e <= t.valueA
            case C.between:
              return e > t.valueA && e < t.valueB
            case C.notBetween:
              return !(e > t.valueA && e < t.valueB)
          }
        }
        _onWatchdogStateChanged(e) {
          if (this.watchdogState !== e) {
            L.logInfo(`Watchdog state changed to: ${e}`),
              (this.watchdogState = e)
            for (const t of this._onWatchdogStateChangesDelegates) t(e)
            this._requestWduInfo()
          }
        }
        _requestWduInfo() {
          L.logVerbose("Request WDU Info"), this.send(W.requestWduInfoCommand())
        }
        _checkWatchdog() {
          let e = this._watchdogDuration
          return (
            this._oldHeartbeatDurationDivider++,
            A.elapsedSeconds(this._lastReceivedMessageTimestamp) > 10
              ? ((e = 9e3),
                this._onWatchdogStateChanged(M.noConnectionToWdu),
                this._webSocketManager.connect(),
                L.logInfo("No heartbeat from WDU received! Recreate websocket"))
              : this.watchdogState === M.noConnectionToWdu &&
                this._onWatchdogStateChanged(M.noConnectionToDigitalSwitching),
            ((!this._wduSendsHeartbeat &&
              this._oldHeartbeatDurationDivider > 1 &&
              A.elapsedSeconds(this._lastReceivedMessageTimestamp) > 4) ||
              !this._wduInfoReceived) &&
              (L.logVerbose("Send heartbeat for older wdu firmwares"),
              this._requestWduInfo(),
              (this._oldHeartbeatDurationDivider = 0)),
            this.watchdogState !== M.noConnectionToWdu &&
              (A.elapsedSeconds(this._digitalSwitchingHeartbeatTimestamp) > 12
                ? this._onWatchdogStateChanged(M.noConnectionToDigitalSwitching)
                : this._onWatchdogStateChanged(M.ok)),
            e
          )
        }
        _watchdogLoop() {
          const e = this._checkWatchdog()
          setTimeout(() => this._watchdogLoop(), e)
        }
      }
      class z {
        static xhrRequest(e, t, i) {
          return new Promise((n, o) => {
            e.open(t, i, !0),
              (e.onload = () => {
                e.status >= 200 && e.status < 400
                  ? n(e.response)
                  : (L.logError(
                      `Error response from xhrRequest, url: ${i}`,
                      e.statusText
                    ),
                    o({ status: e.status, statusText: e.statusText }))
              }),
              (e.onerror = (t) => {
                L.logError(e, t),
                  o({ status: e.status, statusText: e.statusText })
              }),
              e.send()
          })
        }
        static getJsonFile(e) {
          const t = new XMLHttpRequest()
          t.overrideMimeType("application/json"), (t.responseType = "json")
          return z.retryPromise((i, n) => {
            t.open("GET", e, !0),
              (t.onload = () => {
                t.status >= 200 && t.status < 400
                  ? i(t.response)
                  : (L.logError(`Error loading file ${e}`, t.statusText),
                    n({ status: t.status, statusText: t.statusText }))
              }),
              (t.onerror = (e) => {
                L.logError(t, e),
                  n({ status: t.status, statusText: t.statusText })
              }),
              t.send()
          }, 10)
        }
        static retryPromise(e, t, i = 100) {
          return m(this, void 0, void 0, function* () {
            try {
              return yield new Promise(e)
            } catch (n) {
              return t > 0
                ? (yield new Promise((e) => setTimeout(e, i)),
                  z.retryPromise(e, t - 1, i))
                : (L.logError(`Failed to execute promise, retries left ${t}`),
                  Promise.reject(n))
            }
          })
        }
      }
      !(function (e) {
        ;(e[(e.mfd = 0)] = "mfd"),
          (e[(e.nmea = 1)] = "nmea"),
          (e[(e.virtual = 2)] = "virtual")
      })(T || (T = {}))
      class q {
        constructor() {
          ;(this._nmeaSignalInfoMap = new Map()),
            (this._virtualSignalInfoMap = new Map())
        }
        get useChannelItems() {
          return this._useChannelItems
        }
        decodeN2KDataItem(e) {
          if (e.messagecmd === S.statusUpdate) {
            const t = e.data[0] | (e.data[1] << 8),
              i = new U()
            return (
              (i.signalId = t),
              (i.unavailable = 0 != (128 & e.data[2])),
              (i.valueTypeIdentifier = e.data[3] | (e.data[4] << 8)),
              (i.value = this._getValue(t, e.data, 5)),
              i
            )
          }
          return null
        }
        decodeMFDChannelItem(e) {
          const t = e.data[0] | (e.data[1] << 8),
            i = new P()
          return (
            (i.signalId = t),
            e.messagecmd === y.statusUpdate
              ? ((i.signalId = t),
                (i.type = _.statusUpdate),
                (i.valueTypeIdentifier = e.data[3]),
                (i.value = this._getInt32Value(t, e.data, 4)),
                (i.unavailable = 0 != (128 & e.data[2])),
                i)
              : e.messagecmd === y.toggle
              ? ((i.type = _.pulse),
                (i.onOffStatus = 0 != (1 & e.data[2])),
                (i.err1FT = 0 != (2 & e.data[2])),
                (i.err2UC = 0 != (8 & e.data[2])),
                (i.unavailable = 0 != (128 & e.data[2])),
                i)
              : e.messagecmd === y.momentary
              ? ((i.type = _.momentary),
                (i.onOffStatus = 0 != (1 & e.data[2])),
                (i.err1FT = 0 != (2 & e.data[2])),
                (i.err2UC = 0 != (8 & e.data[2])),
                (i.unavailable = 0 != (128 & e.data[2])),
                i)
              : e.messagecmd === y.dimmerUpdate
              ? ((i.type = _.dimmer),
                (i.onOffStatus = 0 != (1 & e.data[2])),
                (i.err1FT = 0 != (2 & e.data[2])),
                (i.err2UC = 0 != (8 & e.data[2])),
                (i.unavailable = 0 != (128 & e.data[2])),
                (i.dimmerValue = e.data[3] | (e.data[4] << 8)),
                i)
              : null
          )
        }
        getVirtualSignals(e) {
          const t = this._virtualSignalInfoMap.get(e)
          return null != t ? t : []
        }
        _getInt32Value(e, t, i) {
          const n = new Uint8Array(t)
          return new DataView(n.buffer).getInt32(i, !0)
        }
        _getValue(e, t, i) {
          const n = new Uint8Array(t),
            o = new DataView(n.buffer)
          let a = x.int32
          if (this.useChannelItems) {
            const t = this._nmeaSignalInfoMap.get(e)
            a = null != t ? t.dataType : x.int32
          }
          switch (a) {
            case x.int8:
              return o.getInt8(i)
            case x.uint8:
              return o.getUint8(i)
            case x.int16:
              return o.getInt16(i, !0)
            case x.uint16:
              return o.getUint16(i, !0)
            case x.int32:
              return o.getInt32(i, !0)
            case x.uint32:
              return o.getUint32(i, !0)
            case x.int64:
              return new Number(o.getBigInt64(i, !0)).valueOf()
            case x.uint64:
              return new Number(o.getBigUint64(i, !0)).valueOf()
            case x.bit:
              return 1 & o.getUint8(i)
          }
        }
        initialize(e) {
          return m(this, void 0, void 0, function* () {
            if (((this._useChannelItems = e), e)) {
              const e = yield z.getJsonFile("signal-info.json")
              if (null != e) {
                for (const t of e.filter((e) => e.type === T.nmea))
                  this._nmeaSignalInfoMap.set(t.signalId, t)
                for (const t of e.filter((e) => e.type === T.virtual)) {
                  const e = t.sourceSignalId
                  if (this._virtualSignalInfoMap.has(e)) {
                    this._virtualSignalInfoMap.get(e).push(t)
                  } else this._virtualSignalInfoMap.set(e, [t])
                }
              }
            }
          })
        }
      }
      class V {
        constructor(e) {
          ;(this._settings = []),
            (this._communicationHandler = null),
            (this._onSettingsChangedDelegate = []),
            (this._communicationHandler = e),
            this._communicationHandler.addOnCommandReceivedDelegate((e) =>
              this._onCommandReceived(e)
            )
        }
        load() {
          return m(this, void 0, void 0, function* () {
            const e = yield z.getJsonFile("wduSettings.json")
            this._settings.splice(0, this._settings.length)
            for (const t of e.Settings)
              null == t.isExternalSetting && (t.isExternalSetting = !1),
                null == t.isOverridden && (t.isOverridden = !1),
                this.settings.push(t)
            for (const t of this._onSettingsChangedDelegate) t()
          })
        }
        get isLoaded() {
          return this._settings.length > 0
        }
        get settings() {
          return this._settings
        }
        getSetting(e) {
          return this._settings.find((t) => t.title === e).currentSetting.symbol
        }
        addOnSettingsReloadedDelegate(e) {
          this._onSettingsChangedDelegate.push(e)
        }
        _onCommandReceived(e) {
          if (e === D.settingsUpdated) this.load()
        }
      }
      !(function (e) {
        ;(e.language = "Language"),
          (e.depth = "Depth"),
          (e.distanceUnit = "DistanceUnit"),
          (e.fuelEconomyUnit = "FuelEconomyUnit"),
          (e.height = "Height"),
          (e.pressure = "Pressure"),
          (e.atmosphericPressure = "AtmosphericPressure"),
          (e.speed = "Speed"),
          (e.temperature = "Temperature"),
          (e.volume = "Volume"),
          (e.volumeRate = "VolumeRate"),
          (e.screensaver = "ScreenSaver")
      })(I || (I = {}))
      class H {
        static cleanUrl(e) {
          if (!e.includes("?")) return e
          const t = e.split("?")
          let i = e
          return (
            t.forEach((e, t) => {
              0 === t ? ((i = e), (i += "?")) : ((i += e), (i += "&"))
            }),
            (i = i.substring(0, i.length - 1)),
            i
          )
        }
        static getUrlParamValue(e) {
          const t = new URL(H.cleanUrl(window.location.href)).searchParams.get(
            e
          )
          return null == t ? "" : t
        }
        static removeUrlParameter(e) {
          const t = this.removeUrlParameterHref(e, window.location.href)
          window.history.pushState("", "", t.toString())
        }
        static removeUrlParameterHref(e, t) {
          const i = new URL(H.cleanUrl(t))
          return i.searchParams.delete(e), i.toString()
        }
        static getPathWithReturnUrl(e, t) {
          const i = new URL(window.location.href)
          return (
            t.forEach((e, t) => {
              i.searchParams.append(t, e)
            }),
            e + "?returnUrl=" + encodeURIComponent(i.toString())
          )
        }
        static createUrlWithReturnParameter(e, t = null) {
          if ("" === e) return ""
          let i = `${"http://" + window.location.host}/${e}`
          const n = H.cleanUrl(window.location.href),
            o = new URL(n),
            a = o.searchParams.getAll("returnUrl")
          o.searchParams.delete("returnUrl"),
            null != t && o.searchParams.append("pageId", t)
          const s = encodeURIComponent(o.toString()),
            r = []
          return (
            a.forEach((e) => {
              r.push("returnUrl=" + encodeURIComponent(e))
            }),
            r.push("returnUrl=" + s),
            r.forEach((e, t) => {
              ;(i += 0 === t ? "?" : "&"), (i += e)
            }),
            i
          )
        }
      }
      class N {
        static hideElement(e) {
          null != e && e.classList.add("hidden")
        }
        static showElement(e) {
          null != e && e.classList.remove("hidden")
        }
        static setElementVisibility(e, t) {
          null != e && (!0 === t ? this.showElement(e) : this.hideElement(e))
        }
        static debounce(e, t, i) {
          let n
          return () => {
            const o = this,
              a = arguments,
              s = i && !n
            clearTimeout(n),
              (n = setTimeout(() => {
                ;(n = null), i || e.apply(o, a)
              }, t)),
              s && e.apply(o, a)
          }
        }
      }
      class F {
        constructor(e) {
          ;(this.active = !1),
            (this.spinner = document.querySelector(".app-selector-link-timer")),
            N.hideElement(this.spinner),
            (this._onExecute = e),
            document.addEventListener(
              "mousedown",
              (e) => (
                this.active && clearTimeout(this._timeout),
                document.addEventListener("mouseup", this._globalMouseUpEvent),
                document.addEventListener(
                  "mousemove",
                  this._globalMouseMoveEvent
                ),
                this.activate(e.clientX, e.clientY),
                !1
              )
            ),
            document.addEventListener(
              "touchstart",
              (e) => {
                this.active && clearTimeout(this._timeout),
                  document.addEventListener(
                    "touchend",
                    this._globalTouchEndEvent
                  ),
                  document.addEventListener(
                    "touchcancel",
                    this._globalTouchEndEvent
                  ),
                  document.addEventListener(
                    "touchmove",
                    this._globalTouchMoveEvent,
                    { passive: !0 }
                  )
                const t = void 0 === e.originalEvent ? e : e.originalEvent
                return (
                  this.activate(t.touches[0].clientX, t.touches[0].clientY), !1
                )
              },
              { passive: !0 }
            ),
            (this._globalMouseUpEvent = (e) => (
              this.deactivate(),
              document.removeEventListener("mouseup", this._globalMouseUpEvent),
              document.removeEventListener(
                "mousemove",
                this._globalMouseMoveEvent
              ),
              !1
            )),
            (this._globalMouseMoveEvent = (e) => {
              if (this.isMoveDistanceTooLong(e.clientX, e.clientY))
                return (
                  this.deactivate(),
                  document.removeEventListener(
                    "mouseup",
                    this._globalMouseUpEvent
                  ),
                  document.removeEventListener(
                    "mousemove",
                    this._globalMouseMoveEvent
                  ),
                  !1
                )
            }),
            (this._globalTouchEndEvent = (e) => (
              this.deactivate(),
              document.removeEventListener(
                "touchend",
                this._globalTouchEndEvent
              ),
              document.removeEventListener(
                "touchcancel",
                this._globalTouchEndEvent
              ),
              document.removeEventListener(
                "touchmove",
                this._globalTouchMoveEvent
              ),
              !1
            )),
            (this._globalTouchMoveEvent = (e) => {
              const t = void 0 === e.originalEvent ? e : e.originalEvent
              return (
                !!this.isMoveDistanceTooLong(
                  t.touches[0].clientX,
                  t.touches[0].clientY
                ) &&
                (this.deactivate(),
                document.removeEventListener(
                  "touchend",
                  this._globalTouchEndEvent
                ),
                document.removeEventListener(
                  "touchcancel",
                  this._globalTouchEndEvent
                ),
                document.removeEventListener(
                  "touchmove",
                  this._globalTouchMoveEvent
                ),
                !1)
              )
            })
        }
        activate(e, t) {
          const i = parseInt(
            window.getComputedStyle(document.body).getPropertyValue("zoom")
          )
          null == i || isNaN(i) || ((e /= i), (t /= i)),
            (this.active = !0),
            (this.spinner.style.left = e + "px"),
            (this.spinner.style.top = t + "px"),
            (this.startPosX = e),
            (this.startPosY = t),
            N.showElement(this.spinner),
            (this._timeout = setTimeout(() => {
              this._onExecute(), N.hideElement(this.spinner)
            }, 1e4))
        }
        deactivate() {
          ;(this.active = !1),
            clearTimeout(this._timeout),
            N.hideElement(this.spinner)
        }
        isMoveDistanceTooLong(e, t) {
          return (
            Math.sqrt(
              Math.pow(this.startPosX - e, 2) + Math.pow(this.startPosY - t, 2)
            ) > 100
          )
        }
      }
      class j {
        constructor(e, t, i, n) {
          ;(this._appHandler = t),
            (this.languageDisplayNames = e.displayNames),
            (this.languageIcons = e.icon),
            this._setLanguageProperties(n),
            (this.locationHref = Z.getApplicationFullPath(e.path)),
            (this.applicationId = e.identifier),
            (this.isDefaultApplication = i),
            (this._applicationElement = document.createElement("div")),
            (this._applicationElement.className = i
              ? "application"
              : "application application-not-default"),
            (this._applicationElement.dataset.applicationid = e.identifier)
          const o = document.createElement("div")
          ;(o.className = "application-icon"),
            this._applicationElement.appendChild(o)
          const a = document.createElement("img")
          ;(a.src = this.icon), o.appendChild(a)
          const s = document.createElement("div")
          ;(s.innerHTML = this.name),
            (s.className = "application-name"),
            this._applicationElement.appendChild(s)
          document
            .querySelector(".application-list")
            .appendChild(this._applicationElement),
            (this._pressEvent = (e) => {
              if (this._pressActive) return !1
              ;(this._pressActive = !0),
                ["mouseup", "touchend", "touchcancel"].forEach((e) =>
                  this._applicationElement.addEventListener(
                    e,
                    this._unpressEvent
                  )
                ),
                e.stopPropagation()
            }),
            (this._unpressEvent = (e) => {
              if (!this._pressActive) return !1
              ;["mouseup", "touchend", "touchcancel"].forEach((e) =>
                this._applicationElement.removeEventListener(
                  e,
                  this._unpressEvent
                )
              ),
                (this._pressActive = !1),
                this._onApplicationClick(),
                e.preventDefault()
            }),
            (this._onTouchMove = (e) => {
              this._pressActive = !1
            }),
            ["mousedown", "touchstart"].forEach((e) =>
              this._applicationElement.addEventListener(e, this._pressEvent)
            ),
            ["touchmove"].forEach((e) =>
              this._applicationElement.addEventListener(e, this._onTouchMove)
            )
        }
        languageRefresh(e) {
          this._setLanguageProperties(e),
            (this._applicationElement.querySelector(
              ".application-name"
            ).innerHTML = this.name)
          this._applicationElement.querySelector(
            ".application-icon > img"
          ).src = this.icon
        }
        _setLanguageProperties(e) {
          {
            const t = this.languageDisplayNames.find((t) => t.symbol === e)
            if (null == t) {
              const e = this.languageDisplayNames.find(
                (e) => "default" === e.symbol
              )
              this.name =
                null == e
                  ? this.languageDisplayNames.length > 0
                    ? this.languageDisplayNames[0].description
                    : "App"
                  : e.description
            } else this.name = t.description
          }
          {
            const t = this.languageIcons.find((t) => t.symbol === e)
            if (null == t) {
              const e = this.languageIcons.find((e) => "default" === e.symbol)
              this.icon =
                null == e
                  ? this.languageIcons.length > 0
                    ? this.languageIcons[0].description
                    : "images/icon-default.png"
                  : e.description
            } else this.icon = t.description
          }
        }
        terminate() {
          ;["mousedown", "touchstart"].forEach((e) =>
            this._applicationElement.removeEventListener(e, this._pressEvent)
          ),
            ["mouseup", "touchend", "touchcancel"].forEach((e) =>
              this._applicationElement.removeEventListener(
                e,
                this._unpressEvent
              )
            )
        }
        _onApplicationClick() {
          if (this._appHandler.editMode) {
            this.isDefaultApplication = !this.isDefaultApplication
            document.querySelector(
              "[data-applicationid='" + this.applicationId + "']"
            ).className = this.isDefaultApplication
              ? "application"
              : "application application-not-default"
          } else window.location.href = this.locationHref
        }
      }
      const B = {
        randomUUID:
          "undefined" != typeof crypto &&
          crypto.randomUUID &&
          crypto.randomUUID.bind(crypto),
      }
      let $
      const J = new Uint8Array(16)
      function K() {
        if (
          !$ &&
          (($ =
            "undefined" != typeof crypto &&
            crypto.getRandomValues &&
            crypto.getRandomValues.bind(crypto)),
          !$)
        )
          throw new Error(
            "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported"
          )
        return $(J)
      }
      const X = []
      for (let i = 0; i < 256; ++i) X.push((i + 256).toString(16).slice(1))
      function G(e, t = 0) {
        return (
          X[e[t + 0]] +
          X[e[t + 1]] +
          X[e[t + 2]] +
          X[e[t + 3]] +
          "-" +
          X[e[t + 4]] +
          X[e[t + 5]] +
          "-" +
          X[e[t + 6]] +
          X[e[t + 7]] +
          "-" +
          X[e[t + 8]] +
          X[e[t + 9]] +
          "-" +
          X[e[t + 10]] +
          X[e[t + 11]] +
          X[e[t + 12]] +
          X[e[t + 13]] +
          X[e[t + 14]] +
          X[e[t + 15]]
        )
      }
      const Y = function (e, t, i) {
        if (B.randomUUID && !t && !e) return B.randomUUID()
        const n = (e = e || {}).random || (e.rng || K)()
        if (((n[6] = (15 & n[6]) | 64), (n[8] = (63 & n[8]) | 128), t)) {
          i = i || 0
          for (let e = 0; e < 16; ++e) t[i + e] = n[e]
          return t
        }
        return G(n)
      }
      class Z {
        constructor(e, t) {
          ;(this._forceShowList = !1),
            (this._applicationItems = []),
            (this._communicationHandler = e),
            this._communicationHandler.addOnCommandReceivedDelegate((e, t) =>
              this._onCommandReceived(e, t)
            ),
            (this._settingsReader = t),
            this._settingsReader.addOnSettingsReloadedDelegate(() =>
              this._updateLanguage()
            )
          try {
            ;(this._clientId = localStorage.getItem("EmpirBusWduClientId")),
              null == this._clientId &&
                ((this._clientId = Y()),
                localStorage.setItem("EmpirBusWduClientId", this._clientId))
          } catch (i) {}
          this._updateApplicationList([], []),
            document
              .querySelector(".application-list-save-button")
              .addEventListener("mousedown", (e) => {
                e.stopPropagation()
              }),
            document
              .querySelector(".application-list-save-button")
              .addEventListener("mouseup", (e) => {
                this.saveDefaultApplications(), e.preventDefault()
              }),
            document
              .querySelector(".application-list-save-button")
              .addEventListener("touchend", (e) => {
                this.saveDefaultApplications(), e.preventDefault()
              })
          "1" ===
            new URLSearchParams(window.location.search).get("forceShowList") &&
            (this._forceShowList = !0),
            document
              .querySelector(".application-selector-edit-button")
              .addEventListener("mousedown", (e) => {
                e.stopPropagation()
              }),
            document
              .querySelector(".application-selector-edit-button")
              .addEventListener("mouseup", (e) => {
                ;(this.editMode = !0), e.preventDefault()
              }),
            document
              .querySelector(".application-selector-edit-button")
              .addEventListener("touchend", (e) => {
                ;(this.editMode = !0), e.preventDefault()
              }),
            new F(() => {
              this.editMode = !0
            })
        }
        _updateLanguage() {
          const e = this._settingsReader.getSetting(I.language)
          for (const t of this._applicationItems) t.languageRefresh(e)
        }
        get clientId() {
          return this._clientId
        }
        get editMode() {
          return this._editMode
        }
        set editMode(e) {
          this._editMode = e
          const t = document.querySelector(".application-selector")
          this._editMode
            ? t.classList.add("application-selector-edit-mode")
            : t.classList.remove("application-selector-edit-mode")
        }
        saveDefaultApplications() {
          const e = []
          for (const t of this._applicationItems)
            t.isDefaultApplication && e.push(t.applicationId)
          this._communicationHandler.send(
            W.applicationSelectorSetDefaultApplication(e, this.clientId)
          ),
            (this.editMode = !1),
            this._refreshShowAllIfEmpty()
        }
        clearDefaultApplication() {
          this._communicationHandler.send(
            W.applicationSelectorClearDefaultApplication()
          )
        }
        _refreshShowAllIfEmpty() {
          const e = document.querySelector(".application-selector")
          null == this._applicationItems.find((e) => e.isDefaultApplication) ||
          this._forceShowList
            ? e.classList.add("application-selector-show-all")
            : e.classList.remove("application-selector-show-all")
        }
        _updateApplicationList(e, t) {
          const i = this._settingsReader.getSetting(I.language)
          for (const n of this._applicationItems) n.terminate()
          this._applicationItems = []
          document.querySelector(".application-list").innerHTML = ""
          for (const n of e) {
            if (!n.showInApplicationSelector) continue
            const e = new j(
              n,
              this,
              void 0 !== t.find((e) => e === n.identifier),
              i
            )
            this._applicationItems.push(e)
          }
          this._refreshShowAllIfEmpty()
        }
        _onCommandReceived(e, t) {
          if (e === D.applicationSelectionListReceived) {
            const e = t.defaultApplications
            if (null != e && 1 === e.length && !this._forceShowList) {
              const i = t.availableApplications.find(
                (t) => t.identifier === e[0]
              )
              if (void 0 !== i)
                return void (window.location.href = Z.getApplicationFullPath(
                  i.path
                ))
            }
            this._updateApplicationList(
              t.availableApplications,
              t.defaultApplications
            )
            document
              .querySelector(".application-selector")
              .classList.remove("hidden")
          }
        }
        static getApplicationFullPath(e) {
          const t = new Map()
          return t.set("forceShowList", "1"), H.getPathWithReturnUrl(e, t)
        }
      }
      class Q {
        get configurationChecksumFromWDU() {
          return this._communicationHandler.configurationChecksumFromWDU
        }
        get configurationChecksumFromProject() {
          return this._configurationChecksumFromProject
        }
        constructor(e) {
          ;(this._configurationChecksumFromProject = null),
            (this._communicationHandler = e)
        }
        initialize() {
          return m(this, void 0, void 0, function* () {
            yield this._getProjectInfo()
          })
        }
        hasBothChecksums() {
          return (
            null != this.configurationChecksumFromWDU &&
            null != this._configurationChecksumFromProject
          )
        }
        isChecksumValid() {
          return (
            null != this.configurationChecksumFromWDU &&
            null != this._configurationChecksumFromProject &&
            this._configurationChecksumFromProject ===
              this.configurationChecksumFromWDU
          )
        }
        _getProjectInfo() {
          return m(this, void 0, void 0, function* () {
            try {
              const e = (yield z.getJsonFile("projectinfo.json"))
                .netlistChecksum
              this._configurationChecksumFromProject =
                null == e ? 0 : parseInt(e, 10)
            } catch (e) {}
          })
        }
      }
      class ee {
        constructor(e, t) {
          ;(this._communicationHandler = null),
            (this._imagesLoaded = !1),
            (this._showWarnings = !0),
            (this._warningHideTimeout = 6e4),
            (this._hideWarningPressTimeout = 5e3),
            (this._lastKnownChecksum = null),
            (this._holdDownTimeout = null),
            (this._communicationHandler = e),
            (this._netlistChecksumHandler = t)
        }
        initialize() {
          ;(this._overlayWebSocketError = document.querySelector(
            ".overlay.overlay-websocket-error"
          )),
            (this._overlayBusError = document.querySelector(
              ".overlay.overlay-bus-error"
            )),
            (this._overlayStarting = document.querySelector(
              ".overlay.overlay-start"
            )),
            (this._overlayReload = document.querySelector(
              ".overlay.overlay-reload"
            )),
            (this._overlayWhitePageBlocker = document.getElementById(
              "overlay-white-page-blocker"
            )),
            (this._overlayWarningChecksum = document.getElementById(
              "checksum-warning-message"
            )),
            (this._overlayWarningTest = document.getElementById(
              "test-warning-message"
            )),
            this._setOverlayStarting(!0),
            this._setOverlayWebSocketError(!1),
            this._setOverlayBusError(!1),
            this._setOverlayReload(!1),
            this._drawOverlayWarnings(),
            this._removeWhitePageBlocker(),
            this._imageLoadedNotifier(),
            this._registerWarningTouchEvents(),
            this._communicationHandler.addWatchdogStateChangedDelegate((e) =>
              this._onSocketStateChanged(e)
            ),
            this._communicationHandler.addOnCommandReceivedDelegate((e) =>
              this._onCommandReceived(e)
            ),
            (this._globalMouseUpEvent = (e) => (
              this._buttonUp(e), e.preventDefault(), !1
            ))
        }
        _imageLoadedNotifier() {
          return m(this, void 0, void 0, function* () {
            yield Promise.all(
              Array.from(document.images).map((e) =>
                e.complete
                  ? Promise.resolve(0 !== e.naturalHeight)
                  : new Promise((t) => {
                      e.addEventListener("load", () => t(!0)),
                        e.addEventListener("error", () => t(!1))
                    })
              )
            ).then((e) => {
              e.every((e) => e),
                (this._imagesLoaded = !0),
                this._calculateOverlay()
            })
          })
        }
        _hideWarnings() {
          this._showWarnings &&
            ((this._showWarnings = !1),
            this._drawOverlayWarnings(),
            setTimeout(() => {
              ;(this._showWarnings = !0), this._drawOverlayWarnings()
            }, this._warningHideTimeout))
        }
        _drawOverlayWarnings() {
          this._calculateChecksumWarning(), this._calculateTestWaring()
        }
        _registerWarningTouchEvents() {
          ;["mousedown", "touchstart"].forEach((e) => {
            this._overlayWarningTest.addEventListener(e, (e) => {
              this._hideWarningsEventListener(e), e.stopPropagation()
            }),
              this._overlayWarningChecksum.addEventListener(e, (e) => {
                this._hideWarningsEventListener(e), e.stopPropagation()
              })
          })
        }
        _buttonUp(e) {
          if (
            (document.removeEventListener("mouseup", this._globalMouseUpEvent),
            null != this._holdDownTimeout)
          )
            return (
              clearTimeout(this._holdDownTimeout),
              void (this._holdDownTimeout = null)
            )
        }
        _hideWarningsEventListener(e) {
          "mousedown" === e.type &&
            document.addEventListener("mouseup", this._globalMouseUpEvent),
            (this._holdDownTimeout = setTimeout(
              () => this._hideWarnings(),
              this._hideWarningPressTimeout
            )),
            e.preventDefault()
        }
        _removeWhitePageBlocker() {
          null != this._overlayWhitePageBlocker &&
            this._overlayWhitePageBlocker.remove()
        }
        _setOverlayWebSocketError(e) {
          N.setElementVisibility(this._overlayWebSocketError, e)
        }
        _setOverlayBusError(e) {
          N.setElementVisibility(this._overlayBusError, e)
        }
        _setOverlayStarting(e) {
          null != this._overlayStarting &&
            (e
              ? N.showElement(this._overlayStarting)
              : this._netlistChecksumHandler.hasBothChecksums()
              ? this._netlistChecksumHandler.isChecksumValid()
                ? N.hideElement(this._overlayStarting)
                : (N.showElement(
                    this._overlayStarting.querySelector(".checksum-warning")
                  ),
                  setTimeout(() => {
                    N.hideElement(this._overlayStarting)
                  }, 5e3))
              : setTimeout(() => {
                  this._setOverlayStarting(!1)
                }, 500))
        }
        _setOverlayReload(e) {
          N.setElementVisibility(this._overlayReload, e)
        }
        _calculateTestWaring() {
          if (null != this._overlayWarningTest) {
            const e = this._overlayWarningTest.innerText
            null != e && e.trim().length > 0 && this._showWarnings
              ? N.setElementVisibility(this._overlayWarningTest, !0)
              : N.setElementVisibility(this._overlayWarningTest, !1)
          }
        }
        _calculateChecksumWarning() {
          if (this._netlistChecksumHandler.hasBothChecksums()) {
            let e = this._showWarnings
            L.logDebug("show warnings: " + this._showWarnings),
              null != this._lastKnownChecksum &&
                this._lastKnownChecksum !==
                  this._netlistChecksumHandler.configurationChecksumFromWDU &&
                ((e = !0), L.logDebug("Last known checksum has changed!")),
              this._netlistChecksumHandler.isChecksumValid()
                ? this._setChecksumBusError(!1)
                : e
                ? (L.logDebug(
                    "Configuration checksum from projectinfo: " +
                      this._netlistChecksumHandler
                        .configurationChecksumFromProject
                  ),
                  L.logDebug(
                    "Configuration checksum from WDU: " +
                      this._netlistChecksumHandler.configurationChecksumFromWDU
                  ),
                  L.logDebug("Last known checksum: " + this._lastKnownChecksum),
                  this._setChecksumBusError(!0))
                : this._setChecksumBusError(!1)
          }
          this._lastKnownChecksum =
            this._netlistChecksumHandler.configurationChecksumFromWDU
        }
        _setChecksumBusError(e) {
          N.setElementVisibility(this._overlayWarningChecksum, e)
        }
        _onSocketStateChanged(e) {
          ;(this._watchdogState = e), this._calculateOverlay()
        }
        _calculateOverlay() {
          if (this._imagesLoaded)
            switch (this._watchdogState) {
              case M.ok:
                this._setOverlayWebSocketError(!1),
                  this._setOverlayBusError(!1),
                  this._setOverlayStarting(!1)
                break
              case M.noConnectionToWdu:
                this._setOverlayWebSocketError(!0), this._setOverlayBusError(!1)
                break
              case M.noConnectionToDigitalSwitching:
                this._setOverlayWebSocketError(!1), this._setOverlayBusError(!0)
            }
        }
        _onCommandReceived(e) {
          switch (e) {
            case D.forcePageReload:
              this._setOverlayReload(!0)
              break
            case D.checksumReceived:
              L.logDebug("Service Provider checksum received"),
                this._calculateChecksumWarning()
          }
        }
      }
      const te = new (class {
        initialize() {
          return m(this, void 0, void 0, function* () {
            const e = new R(),
              t = new q()
            yield t.initialize(!1)
            const i = new O(e, t),
              n = new Q(i)
            yield n.initialize()
            const o = new V(i)
            yield o.load()
            new ee(i, n).initialize()
            const a = new Z(i, o)
            A.start(),
              e.addOnSocketStateChangedDelegate((t) => {
                t === f.open &&
                  e.sendJson(
                    W.requestApplicationSelectorInfoAvailableApplications(
                      a.clientId
                    )
                  )
              }),
              e.connect(),
              L.initialize(),
              onSystemHasStarted()
          })
        }
      })()
      document.addEventListener("DOMContentLoaded", () => {
        te.initialize()
      })
    })()
})()
